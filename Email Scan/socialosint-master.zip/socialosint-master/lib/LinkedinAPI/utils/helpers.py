def get_id_from_urn(urn):
    return urn.split(":")[3]