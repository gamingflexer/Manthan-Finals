from .linkedin import Linkedin

__title__ = "linkedin_api"
__version__ = "1.0.0"
__description__ = "Python wrapper for linkeding api"

__author__ = "Tom Quirk"
__email__ = "tomquirkacc@gmail.com"

__all__ = ["Linkedin"]