class SentryBlockException(Exception):
    pass