# SocialFish
SocialFish fake pishing social sites

Store Login Data in text file and send to email

#FaceBook Desktop
![alt tag](https://github.com/Elm0D/SocialFish/blob/master/fb_standard/screencapture.png)

#FaceBook Mobile
![alt tag](https://github.com/Elm0D/SocialFish/blob/master/fb_mobile/Screenshot.png)


