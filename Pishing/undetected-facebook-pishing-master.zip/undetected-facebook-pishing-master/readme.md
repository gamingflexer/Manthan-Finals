# Private Undetected "Pishing Website" Facebook Pishing

## Using the script

Only for intellectual use, we are not responsible for damages to third parties.
We do not encourage hacking in any of the aforementioned ways

**This uses IP2Location Database Lite**


## Contributing

The easiest way is to fork this repository on GitHub, modify existing lines, or add your own, and then submit a [pull request](https://help.github.com/en/articles/about-pull-requests). If you could quote a source link or text with your commit message.


## Features
 * Auto Detect Desktop o Mobile
 * Auto Redirect to Desktop o Mobile Pishing


## Questions or feedback?

You can either open an issue here on GitHub.
