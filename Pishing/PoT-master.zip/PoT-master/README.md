# Phishing on Twitter

## Generate tweet automatically like him/her

![graph1](https://github.com/omergunal/T/blob/master/img/12.png) ![t3](https://github.com/omergunal/PoT/blob/master/img/t3.png)

### How it works?

- 1- Collect data from target's twitter account
- 2- Find target's friend and copy her/him account
- 3- Generate tweet automatically with markov chain algorithm and send it

### Installation

```bash
git clone https://github.com/omergunal/PoT
cd PoT
pip3 install -r requirements.txt
```

Update your api keys in "PoT.cfg". Go to <https://apps.twitter.com/> and get API keys

### Usage

```bash
python3 PoT.py -u username
```

### ScreenShots

![t1](https://github.com/omergunal/PoT/blob/master/img/2.png) ![t2](https://github.com/omergunal/PoT/blob/master/img/t2.png) ![t3](https://github.com/omergunal/PoT/blob/master/img/t3.png)

# !

Don't use for illegal activity
