package main

import (
	"gopkg.in/sundowndev/phoneinfoga.v2/cmd"
)

func main() {
	cmd.Execute()
}
