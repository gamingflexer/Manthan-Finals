# emailosint
emailosint is a tool for gathering email accounts informations (ip,hostname,country, etc...) 

[![forthebadge](https://forthebadge.com/images/badges/made-with-python.svg)](https://forthebadge.com)

# Installation
```
git clone https://github.com/krishpranav/emailosint
cd emailosint
python3 -m pip install -r requirements.txt
python3 emailosint.py
```
